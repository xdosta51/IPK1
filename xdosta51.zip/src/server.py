import socket #knihovna pro sockety vytvoreni serveru
import re # knihovna pro reg. vyrazy
import sys # kontrola argumentu

if len(sys.argv) is not 2: 
    print("Chyba spatny pocet argumentu")
    sys.exit(1)
port_arg = int(sys.argv[1])
if not isinstance(port_arg,int) or port_arg < 1024 or port_arg > 65535:
    print("Vlozen spatny format pro port")
    sys.exit(1)

# vytvoreni tcp ip soketu
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# nabindovani soketu na port
server_address = ('localhost', port_arg)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind(server_address)

# naslouchani prichozim pripojenim
sock.listen(8)

jetamchyba = False # 400 nebo 404

while True:
    # cekani na pripojeni
    connection = None
    try: #navazani komunikace
        connection, client_address = sock.accept()
        while True:
            data = connection.recv(1024) # prijmuti dat
            datanew = data.decode("utf-8")
            gethttp = datanew
            gethttp = gethttp.split('\n', 1)
            lajna = gethttp[0]
            words = lajna.split()
            
            if words[-1] == 'HTTP/1.1' or words[-1] == 'HTTP/1.0': #kontrola verze http
                version = 'HTTP/1.1' + ' '
            else:
                messageforclient = 'HTTP/1.1' + ' ' + '500 Internal Server Error\r\n\r\n'
                messageforclient = messageforclient.encode()
                connection.sendall(messageforclient)
                break
            
            itisok = re.search(' /resolve\\?|/resolve ', datanew) # kontrola spravneho dotazu 
            itisturbo = re.search('/dns-query | /dns-query\\?', datanew)
            if not (itisok) and not (itisturbo):
                messageforclient = version + '400 Bad Request\r\n\r\n'
                messageforclient = messageforclient.encode()
                connection.sendall(messageforclient)
                break
            
            itisget = re.search('GET (.+?) HTTP', datanew) #kontrola spravne metody
            itispost = re.search('^POST (.+?) HTTP', datanew)
            if itisget:
                itisget = itisget.group(1)
            elif itispost:
                itispost = itispost.group(1)
            else: #metoda neni podporovana vyhozeni chyby
                messageforclient = version + '405 Method Not Allowed\r\n\r\n'
                messageforclient = messageforclient.encode()
                connection.sendall(messageforclient)
                break
            if itisget:
                kontrola1 = words[1].endswith("PTR") #kontrola typu
                kontrola2 = words[1].endswith("A")
                if not kontrola1 and not kontrola2:
                    messageforclient = version + '400 Bad Request\r\n\r\n'
                    messageforclient = messageforclient.encode()
                    connection.sendall(messageforclient)
                    break
                m = re.search('name=(.+?)&', datanew)
                ipadr = re.search('name=(.+?) HTTP', datanew)
                
                if m:
                    found = m.group(1)
                    n = re.search('type=(.+?) ', datanew)
                    foundtype = n.group(1)
                    if foundtype != "A" and foundtype != "PTR":
                        messageforclient = version + '400 Bad Request\r\n\r\n'
                        messageforclient = messageforclient.encode()
                        connection.sendall(messageforclient)
                        break
                elif ipadr:
                    foundtype = 'PTR'
                    found = ipadr.group(1)
                else:
                    messageforclient = version + '400 Bad Request\r\n\r\n'
                    messageforclient = messageforclient.encode()
                    connection.sendall(messageforclient)
                    break
                if foundtype == 'A': 
                    isfound = re.match('^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$', found)
                    if isfound:
                        zpravaproklienta = version + '400 Bad Request\r\n\r\n'
                    else:
                        try:
                            socket.gethostbyname(found)
                            zpravaproklienta = found + ':' + foundtype + '=' + socket.gethostbyname(found) + '\n'
                        except: 
                            zpravaproklienta = version + '404 Not Found\r\n\r\n'
                        
                elif foundtype == 'PTR':
                    isfound = re.match('^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$', found)
                    if not isfound:
                        zpravaproklienta = version + '400 Bad Request\r\n\r\n'
                    else:
                        try:
                            socket.gethostbyaddr(found)
                            getnamee = socket.gethostbyaddr(found)
                            zpravaproklienta = found + ':' + foundtype + '=' + getnamee[0] + '\n'
                        except: 
                            zpravaproklienta = version + '404 Not Found\r\n\r\n'
                        
                        
                if not zpravaproklienta == version + '404 Not Found\r\n\r\n' and not zpravaproklienta == version + '400 Bad Request\r\n\r\n':
                    messageforclient = version + '200 OK\r\n\r\n' + zpravaproklienta
                
                else:
                    messageforclient = zpravaproklienta
                messageforclient = messageforclient.encode()
            elif itispost:
                # rozlozeni na jednotlive pozadavky
                groupof = datanew.split('\r\n\r\n', 1)
                
                test = groupof[1].split('\r\n')
                
                groupof = groupof[1].split('\n')
               
                counter = len(groupof)
                messageforclient = ''
                hlavicka = ''
                for addr in groupof: #pruchod po radcich a skladani vystupniho souboru pro klienta
                    addr = addr.replace(' ', '')
                    addr = addr.replace('\t', '')
                    addr = addr.replace('\r', '')
                    addr = addr.replace('\n', '')
                    typeof = re.search(':(.+?)$', addr)
                    
                    if typeof:
                        typeof = typeof.group(1)
                    else:
                        continue
                    messagetok = addr + '='
                    
                    iptosolve = re.search('(.+?):PTR$', addr)
                    if iptosolve:
                        addr = iptosolve.group(1)
                        typeof = 'P'
                    else :
                        iptosolve = re.search('(.+?):A$', addr)
                        if iptosolve:
                            addr = iptosolve.group(1)
                            typeof = 'A'
                        else:
                            hlavicka = version + '400 Bad Request\r\n\r\n'
                            jetamchyba = True
                            continue
                        
                    if typeof == 'A':
                        isaddr = re.match('^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$', addr)
                        if isaddr:
                            hlavicka = version + '200 OK\r\n\r\n'
                            jetamchyba = True
                        else:
                            try:
                                messageforclient = messageforclient + messagetok  + socket.gethostbyname(addr) + '\n'
                            except:
                                hlavicka = version + '200 OK\r\n\r\n'
                            
                    elif typeof == 'P':
                        isaddr = re.match('^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$', addr)
                        if not isaddr:
                            hlavicka = version + '200 OK\r\n\r\n'
                            jetamchyba = True
                        else:
                            try:
                                getnamee = socket.gethostbyaddr(addr)
                                messageforclient = messageforclient + messagetok + getnamee[0] +'\n'
                            except:
                                hlavicka = version + '200 OK\r\n\r\n'
                    
                        
                    else:   
                        continue
                if not hlavicka: #kontrola chyb zpetny encode a poslani klientovi
                    hlavicka = version + '200 OK\r\n\r\n'
                if not messageforclient:
                    if not jetamchyba:
                        hlavicka = version + '404 Not Found\r\n\r\n'
                    else :
                        hlavicka = version + '400 Bad Request\r\n\r\n'
                        jetamchyba = False
                jetamchyba = False
                messageforclient = hlavicka + messageforclient
                messageforclient = messageforclient.encode()

            else : #nastala chyba odeslani dat klientovi
                messageforclient = version + '400 Bad Request\r\n\r\n'
                messageforclient = messageforclient.encode()
                connection.sendall(messageforclient)
                break
            if data: #pokud vse bylo v poradku poslani dat klientovi
                connection.sendall(messageforclient)
                break
            else:
                
                break
    except KeyboardInterrupt: # odchyceni sigintu
        try:
            if connection:
                connection.close()
        except: pass
        break
    finally: #uzavreni spojeni s klientem
        if connection:
            connection.close()
sock.shutdown #nakonec uzavreni soketu
sock.close()

