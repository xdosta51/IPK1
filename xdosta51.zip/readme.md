# IPK projekt 1

* Autor: **xdosta51** <br>
* Programovaci jazyk: Python3<br>
* Importovane knihovny: re, sys, socket <br>

## Spusteni skriptu

Program se spousti pomoci Makefile, prikazem *make run PORT=[port]*, kde port je cislo portu, na kterem je server spusten<br>

## Strucny popis funkcnosti
Server je implementovan pomoci knihovny *socket*, parse potrebnych veci je realizovani pomoci regularnich vyrazu z knihovny *re* a k osetreni argumentu je importovana knihovna
*sys*, aby nebylo mozne spoustet server na nedovolenem portu.
Po spusteni serveru pomoci prilozeneho makefilu a vybrani prislusneho portu, se provede pokus o bind socketu na uvedenem portu,
skript bezi ve smycce, ukoncuje ho az prislusny sigint signal. Server po naslouchani ceka na pripojeni od klienta, ihned pote, co prijde od klienta pozadavek dostava zpetnou zpravu
s daty, o ktere si zadal a v hlavicce response kod, pak se pripojeni s klientem ukonci. <br>

Podporovane jsou pouze verze HTTP 1.1 a 1.0

Pozadavek od klienta je v metode GET formou GET /resolve?name=apple.com&type=A HTTP/1.1 <br>
v metode POST se jedna o vice dotazu na vice radcich formou DOTAZ:TYP
<br>

Response kody, ktere mohou nastat:

 - 200 OK, pokud vsechno probehlo v poradku, v tele bude odpoved
 - 500 Internal Server Error, pokud je spatna verze http, kterou server nezpracuje
 - 400 pokud hodnoty pro GET nebo POST, nebyli spravne specifikovany
 - 404 Not Found, pokud nebyla nalezena odpoved pro dotaz
 - 405 Method not allowed, pri pokusu o jinou metodu nez je GET nebo POST

 Skript v pripade response kodu 200 OK odesila v tele zpravu klientovi s odpovedmi, o ktere si zadal 
 V pripade ze se jednalo o GET dojde v tele odpovedi jedna odpoved typu DOTAZ:TYP=ODPOVED napr.: apple.com:A=17.142.160.59
 V pripade ze se jednalo o POST a je to 200 OK, tak se odesle odpoved na jednom ci vice radcich a kazdy radek bude obsahovat 
 DOTAZ:TYP=ODPOVED napr.: apple.com:A=17.142.160.59 stejne jako v metode GET


## Prubeh zivota serveru

 - Skript spusti server na prislusnem portu (knihovna socket)
 - Prijde dotaz od klienta metodou GET nebo POST (napr dotaz CURL)
 - Rozdeleni pozadavku na zpracovani (gethostbyaddr, gethostbyname)
 - Kontrola na chyby, pokud jsou vraci se chybovy kod
 - Pokud vse probehlo v pohode vraci se 200 OK a v body odpoved na dotaz
 - Ukonceni spojeni s klientem ze strany serveru
 - Cekani na dalsi pripojeni.
 - ukonceni serveru napr.: ctrl+c


## Osetreni chyb
V prichozich datech bylo potreba osetrit nekolik chybne vlozenych parametru, napriklad dotaz na ip adresu, kdyz je vstupem ip adresa, nebo
obdobne u domenoveho jmena, take je potreba kontrolovat zda se jedna o dotaz na :A nebo :PTR, pote bylo taky nutne kontrolovat spravnost IPv4 formatu
dale je v projektu kontrolovana metoda, zda se jedna o GET nebo POST, take bylo potreba kontrolovat spravnost dotazu dns-query nebo resolve. Toto vsechno
je v projektu osetreni pomoci regularnich vyrazu importovanych z knihovny re. Nejdulezitejsi osetreni chyb je v projektu implementovani pomoci try catch finally

## Zaver
Server je jako celek plne funkcni, je mozne, ze muzou nastat nejake chyby, ktere nejsou overeny, ale je implementovan presne podle zadani a blizsich specifikaci, ktere probehli na foru.